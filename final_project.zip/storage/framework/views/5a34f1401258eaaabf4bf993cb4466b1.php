<?php $__env->startSection('admin_main_content'); ?>

<section id="list-employee">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4>List of All Notice</h4>
                    </div>
                    <div class="card-body  table-responsive">
                        <table class="table table-hover table-striped">
                            <tr>
                                <th>Sn</th>
                                <th>Title</th>
                                <th>Details</th>
                                <th>PDF</th>
                                <th>Date</th>
                                <th>Status</th>
                            </tr>

                            <?php $__empty_1 = true; $__currentLoopData = $allNotice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e(++$key); ?></td>
                                    <td><?php echo e($data->notice_title); ?></td>
                                    <td><?php echo e($data->notice_details); ?></td>
                                    <td>
                                        <a class="badge bg-primary" target="_blank" href="<?php echo e($data->notice_image); ?>">Download PDF</a>
                                    </td>
                                    <td><?php echo e($data->created_at->format('Y-M-d')); ?></td>
                                    <td>
                                        <div class="btn-group">
                                            <a href="<?php echo e(route('admin.notice.edit', $data->id)); ?>" class="btn btn-primary btn-sm"><i class="fa-solid fa-pen-to-square"></i></a>
                                            <a href="<?php echo e(route('admin.notice.delete', $data->id)); ?>" class="btn btn-danger btn-sm"><i class="fa-solid fa-trash"></i></a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <h4>No Notice Found !</h4>
                            <?php endif; ?>
                        </table>
                        <br><br>
                        <?php echo e($allNotice->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>




<?php $__env->startSection('search'); ?>
<div class="navbar-nav align-items-center">
    <div class="nav-item d-flex align-items-center  border-light rounded px-3">
      <i class="bx bx-search fs-4 lh-0"></i>
      <form action="<?php echo e(route('admin.notice.search')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="btn-group">
            <input
            type="text" name="search_notice"
            class="form-control border-0 shadow-none"
            placeholder="Search notice .."
            aria-label="Search..."
          />
          <button type="submit" class="btn btn-primary">Search</button>
          </div>
      </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\school\happy_school_backup\resources\views/admin/notice/listNotice.blade.php ENDPATH**/ ?>