
<?php $__env->startSection('frontend_layout'); ?>
    <section class="my-5">
        <div class="container">
            <div class="row gy-5">
                <?php $__empty_1 = true; $__currentLoopData = $imageData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-lg-2">
                        <div class="shadow">
                            <img class="img-fluid" src="<?php echo e($data->galary_img); ?>" alt="">
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <h4>No Image Data Found !🤔</h4>
                <?php endif; ?>
            </div>
            
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\school\happy_school_backup\resources\views/frontend/galary/images.blade.php ENDPATH**/ ?>