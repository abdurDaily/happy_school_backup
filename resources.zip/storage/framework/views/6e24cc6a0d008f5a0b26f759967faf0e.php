<?php $__env->startSection('admin_main_content'); ?>

<section id="news_events">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Add a New event..</h4>
                    </div>

                    <div class="card-body">
                        <form action="<?php echo e(route('admin.event.update', $editData->id)); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>

                        <div class="row">
                            <div class="col-lg-7">

                                <label for="event_title" class="mt-2">Event Title <span class="text-danger">*</span> </label>
                                <textarea name="event_title" id="event_title" class="form-control" placeholder="enter event title.."><?php echo e($editData->event_title); ?></textarea>
                                <?php $__errorArgs = ['event_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span> <br>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    

                                <label for="event_detail" class="mt-2">Event Title <span class="text-danger">*</span></label>
                                <textarea name="event_detail" id="event_detail" class="form-control" placeholder="enter the event details..." cols="30" rows="10"><?php echo e($editData->event_detail); ?></textarea>
                                <?php $__errorArgs = ['event_detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span> <br>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                <label for="event_video" class="mt-2">Enter Event YouTube Video Link </label>
                                <input value="<?php echo e($editData->event_video); ?>" type="text" name="event_video" id="event_video" class="form-control" placeholder="toutube video link ....">
                            </div>
                            <div class="col-lg-5 my-auto" style="border:1px solid rgba(227, 223, 223, 0.447);" class="bg-info">
                                <label for="event_img">
                                    <img class="eventtImagePicture" style="max-width: 100%; padding:20px; cursor: pointer;" src="<?php echo e($editData->event_img); ?>" alt="">
                                </label>
                                <input type="file" accept=".jpg,.png,.jpeg" name="event_img" id="event_img" class="d-none event_img">
                                <?php $__errorArgs = ['event_img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                  <br>
                                    <span class="text-danger"><?php echo e($message); ?></span> <br>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary w-100 my-3">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<?php $__env->startPush('additional_js'); ?>
        <script>
            let imageInput = document.querySelector('#event_img')
            let image = document.querySelector('.eventtImagePicture')
            imageInput.addEventListener('change', (e) => {
                const url = URL.createObjectURL(e.target.files[0])
                image.src = url
            })
        </script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\school\happy_school_backup\resources\views/admin/Newsevent/editNews.blade.php ENDPATH**/ ?>