<?php $__env->startSection('admin_main_content'); ?>

<section id="list_routine">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4>List of all routine..</h4>
                    </div>

                    <div class="card-body  table-responsive">
                        <table class="table table-hover table-striped">
                            <tr>
                                <th>Sn.</th>
                                <th>Title</th>
                                <th>Download PDF</th>
                                <th>Action</th>
                            </tr>

                            <?php $__empty_1 = true; $__currentLoopData = $allRoutineData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e(++$key); ?></td>
                                    <td><?php echo e($data->routine_title); ?></td>
                                    <td>
                                        <a class="badge bg-primary" target="_blank" href="<?php echo e($data->routine_image); ?>" ><?php echo e($data->created_at->format('Y-M-D')); ?></a>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <a href="<?php echo e(route('admin.routine.edit', $data->id)); ?>" class="btn btn-primary btn-sm"><i class="fa-solid fa-pen-to-square"></i></a>
                                            <a href="<?php echo e(route('admin.routine.delete', $data->id)); ?>" class="btn btn-danger btn-sm"><i class="fa-solid fa-trash"></i></i></a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                
                            <?php endif; ?>
                        </table>
                        <br>

                    <?php echo e($allRoutineData->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\school\happy_school_backup\resources\views/admin/Routine/listRoutine.blade.php ENDPATH**/ ?>