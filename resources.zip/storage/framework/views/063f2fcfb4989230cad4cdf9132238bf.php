<?php $__env->startSection('admin_main_content'); ?>
    <section id="list">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>All gallery list</h4>
                        </div>
                        <div class="card-body">
                            <table class="table table-hover table-striped">
                                <tr>
                                    <th>Sn.</th>
                                    <th>Gallery Text</th>
                                    <th>About Text</th>
                                    <th>Images</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>

                                <?php $__empty_1 = true; $__currentLoopData = $listData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e(++$key); ?></td>
                                        <td><?php echo e(Str::limit($data->about_galary_text, 100, '......')); ?></td>
                                        <td><?php echo Str::limit($data->about_institute, 100, '......'); ?></td>
                                        <td>
                                            <img style="width: 100px" src="<?php echo e($data->about_galary_img); ?>" alt="">
                                        </td>
                                        <td align="center" valign="middle">
                                           <a href="<?php echo e(route('admin.about.status', $data->id)); ?>">
                                              <i class="<?php echo e($data->status == 0 ? 'fa-regular' : 'fa-solid'); ?> fa-star"></i>
                                           </a>
                                        </td>
                                        <td>
                                            <div class="btn-group">
                                                <a href="<?php echo e(route('admin.edit.about.galary', $data->id)); ?>"
                                                    class="btn btn-primary btn-sm"><i
                                                        class="fa-solid fa-pen-to-square"></i></a>
                                                <a href="<?php echo e(route('admin.delete.about.galary', $data->id)); ?>"
                                                    class="btn btn-danger btn-sm"><i class="fa-solid fa-trash"></i></a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>



                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\school\happy_school_backup\resources\views/admin/about/listaboutgallery.blade.php ENDPATH**/ ?>