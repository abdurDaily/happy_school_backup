<?php $__env->startSection('admin_main_content'); ?>
    <section id="notice">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 mx-auto">
                    <div class="card">
                        <div class="card-header">
                            <h4>Add a New Notice..</h4>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('admin.notice.store')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                                <label for="notice_title">Notice Title &nbsp; <span class="text-danger">*</span> </label>
                                <input type="text" name="notice_title" id="notice_title" class="form-control" placeholder="enter notice title">
                                <?php $__errorArgs = ['notice_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span> <br>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                <label class="mt-3" for="notice_details">Notice Description &nbsp; <span class="text-danger">*</span></label>
                                <textarea name="notice_details" id="notice_details" placeholder="enter notice cause's.." class="form-control" cols="30" rows="10"></textarea>
                                <?php $__errorArgs = ['notice_details'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span> <br>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                <label for="notice_image" class="mt-3">Notice Upload with PDF form &nbsp; <span class="text-danger">*</span></label>
                                <input accept=".pdf" type="file" name="notice_image" id="notice_image" class="form-control p-4">
                                <?php $__errorArgs = ['notice_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span> <br>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                <button class="btn btn-primary w-100 mt-5 py-3">Submit</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\school\happy_school_backup\resources\views/admin/notice/addNotice.blade.php ENDPATH**/ ?>