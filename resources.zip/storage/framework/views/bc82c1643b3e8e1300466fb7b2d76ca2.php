<?php $__env->startSection('admin_main_content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-4 mx-auto card shadow">

                <div class="card-header">
                    <h5 style="margin: 0; padding:0;">Add a bath with section</h5>
                </div>

                <div class="card-body">
                    <form action="<?php echo e(route('insert.new.batch')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <label for="batch_no" class="mb-0">Batch name</label>
                        <input id="batch_no" name="batch_no" type="text" class="form-control"
                            placeholder="Bath name with section">
                        <?php $__errorArgs = ['batch_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <strong class="text-danger"><?php echo e($message); ?></strong>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <?php if($message = Session::get('error')): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </div>
                        <?php endif; ?>

                        <button class="btn btn-primary w-100 mt-3">Upload</button>
                    </form>
                </div>


            </div>

            <div class="col-lg-8 table-responsive mt-5 mt-lg-0">
                <div class="card shadow ">
                    <table class="table table-striped  table-hover text-center text-capitalize ">
                        <tr>
                            <td>Sn.</td>
                            <td>Batch Name</td>
                            <td>Action</td>
                        </tr>

                        <?php $__empty_1 = true; $__currentLoopData = $batchNumber; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e(++$key); ?></td>
                                <td><?php echo e(Str::upper($data->batch_no)); ?></td>
                                <td>
                                    <div class="btn-group">
                                        <a href="<?php echo e(route('edit.batchname', $data->id)); ?>" class="btn btn-primary btn-sm"><i class="fa-solid fa-pen-to-square"></i></a>
                                        <a href="<?php echo e(route('delete.batch', $data->id)); ?>" class="btn btn-danger btn-sm"><i class="fa-solid fa-trash"></i></a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            
                        <?php endif; ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('additional_css'); ?>
    <style>
        @media (max-width: 575.98px) { 
            table{
                width: 100%;
                margin-top: 20px !important;
            }
        }
    </style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\school\happy_school_backup\resources\views/Admin/Attendance/addNewBatch.blade.php ENDPATH**/ ?>