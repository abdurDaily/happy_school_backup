<?php $__env->startSection('admin_main_content'); ?>
    <section id="role">
        <div class="container">
            <div class="card p-3">
                <div class="head-btn d-flex justify-content-start mb-3">
                    <a href="<?php echo e(route('admin.role.list')); ?>" class="btn btn-primary btn-sm py-2 px-4">Edit Role</a>
                </div>
                <div class="row px-2">

                    <div class="col-lg-4 order-md-2 order-sm-1 ">
                        
                        <div class="card shadow">
                            <div class="card-header bg-primary">
                                <h5 style="color: #fff; margin:0;">Inser a New Role</h5>
                            </div>
                            <div class="card-body">
                                <form action="<?php echo e(route('admin.role.store')); ?>" method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <label for="name" class="mt-3">Role Assign</label>
                                    <input type="text" id="name" name="name" class="form-control"
                                        placeholder="enter a role name">
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <strong class="text-danger"><?php echo e($message); ?></strong>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <button class="btn btn-primary w-100 mt-3">Submit</button>
                                </form>
                            </div>
                        </div>
                    </div>


                    <div class="col-lg-8 order-md-1 order-sm-2 ">
                        <div class="card-body" style="padding: 0;">
                            <table class="shadow table table-hover table-striped table-light tab-navigation">
                                <tr>
                                    <th>Sn</th>
                                    <th>Name</th>
                                    <th>Status</th>
                                </tr>

                                <?php $__empty_1 = true; $__currentLoopData = $allRoles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e(++$key); ?></td>
                                        <td><?php echo e($data->name); ?></td>
                                        <td>
                                            <div class="btn-group">
                                                <a href="<?php echo e(route('admin.role.permission',$data->id)); ?>" class="btn btn-primary btn-sm">Permission</a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <h4>No data found!</h4>
                                <?php endif; ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>   
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\school\happy_school_backup\resources\views/admin/role/addRole.blade.php ENDPATH**/ ?>