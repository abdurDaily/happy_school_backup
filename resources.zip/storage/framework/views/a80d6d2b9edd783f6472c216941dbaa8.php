<?php $__env->startSection('admin_main_content'); ?>

<section id="list-employee">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4>list of all employee's</h4>
                    </div>
                    <div class="card-body  table-responsive">
                        <table class="table table-hover table-striped">
                            <tr>
                                <th>Sn</th>
                                <th>Name</th>
                                <th>email</th>
                                <th>image</th>
                                <th>Designation</th>
                                <th>phone</th>
                                <th>about</th>
                                <th>Facebook</th>
                                <th>Twitter</th>
                                <th>status</th>
                            </tr>

                            <?php $__empty_1 = true; $__currentLoopData = $allEmployee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e(++$key); ?></td>
                                    <td><?php echo e($data->name); ?></td>
                                    <td><?php echo e($data->email); ?></td>
                                    <td>
                                        <img style="width: 80px; border-radius: 50%; height:80px; object-fit:cover;" src="<?php echo e($data->employee_image); ?>" alt="">
                                    </td>
                                    <td><?php echo e($data->employee_designation); ?></td>
                                    <td><?php echo e($data->employee_phone); ?></td>
                                    <td><?php echo e($data->employee_about); ?></td>
                                    <td>
                                        <a class="badge bg-primary" href="<?php echo e($data->fb_link); ?>">Facebook</a>
                                    </td>
                                    <td><?php echo e($data->tritter_link); ?></td>
                                    
                                    <td>
                                        <div class="btn-group">
                                            <a href="<?php echo e(route('admin.employee.edit', $data->id)); ?>" class="btn btn-primary btn-sm"><i class="fa-solid fa-pen-to-square"></i></a>
                                            <a href="<?php echo e(route('admin.employee.delete', $data->id)); ?>" class="btn btn-danger btn-sm"><i class="fa-solid fa-trash"></i></a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                
                            <?php endif; ?>
                        </table>
                        <br><br>
                        <?php echo e($allEmployee->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>




<?php $__env->startSection('search'); ?>
<div class="navbar-nav align-items-center">
    <div class="nav-item d-flex align-items-center  border-light rounded px-3">
      <i class="bx bx-search fs-4 lh-0"></i>
      <form action="<?php echo e(route('admin.employee.search')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="btn-group">
            <input
            type="text" name="search_employee"
            class="form-control border-0 shadow-none"
            placeholder="Search..."
            aria-label="Search..."
          />
          <button class="btn btn-primary">Search</button>
          </div>
      </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\school\happy_school_backup\resources\views/admin/employee/listEmployee.blade.php ENDPATH**/ ?>