
<?php $__env->startSection('admin_main_content'); ?>
   
  <section id="lecture">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="card shadow ">
                    <div class="card-header">
                        <h4>Course  Lectures</h4>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('admin.update.course.lecture')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <div class="row">
                                <div class="col-lg-6 mx-auto">
                                   <div class="row">
                                        <div class="col-lg-12">
                                            <label for="subject_name">Subject Name</label>
                                            <select class="form-control" name="subject_name" id="subject_name">
                                                <option value="" disabled selected>Select Subject</option>
                                                <?php $__currentLoopData = $allSubject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($data->id); ?>"><?php echo e($data->subject_name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
        
                                            <?php $__errorArgs = ['subject_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span> <br>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>


                                        <div class="col-lg-12 mt-3">
                                            <label for="video_title">Video Title</label>
                                            <input type="text" name="video_title" class="form-control py-3" id="video_title" placeholder="Video Title..">
                                            <?php $__errorArgs = ['video_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($messge); ?></span> <br>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        

                                        <div class="col-lg-12 mt-3">
                                            <label for="video_link">Video URL</label>
                                            <input type="text" name="video_link" id="video_link" placeholder="enter video link" class="form-control py-3">
        
                                            <?php $__errorArgs = ['video_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span> <br>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                   </div>


                                   <div class="submit-btn d-flex justify-content-end mt-4">
                                      <button class="btn btn-primary w-100 py-3">Submit</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>






<?php $__env->startPush('additional_css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('vendor/sweetalert/css/select2.min.css')); ?>" />
    <style>
        .select2-container {
            border: 1px solid #D3D8DE;
            border-radius: 6px;
        }
        .select2-container--default .select2-selection--single {
            border: none;
            height: 40px;
            text-align: center;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .select2-search__field {
            border: 0;
            outline: 0;
        }

        .batch_no,
        .select2-selection__rendered {
            border: 0px solid transparent;
            outline: none;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('additional_js'); ?>
    <script src="<?php echo e(asset('vendor/sweetalert/js/select2.min.js')); ?>"></script>

    <script>
        $(document).ready(function() {
            $('#subject_name').select2();
        });
    </script>
<?php $__env->stopPush(); ?>



<?php echo $__env->make('layouts.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\school\happy_school_backup\resources\views/admin/courses/courseListSearch.blade.php ENDPATH**/ ?>