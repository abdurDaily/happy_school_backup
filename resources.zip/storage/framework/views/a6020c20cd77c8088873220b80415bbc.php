
<?php $__env->startSection('frontend_layout'); ?>


    <div class="preloader">
        <img class="preloader__image" width="60" src="frontend_assets/images/loader.png" alt="" />
    </div>

    <!-- /.preloader -->
    <div class="page-wrapper">


        <div class="stricky-header stricked-menu main-menu">
            <div class="sticky-header__content">

            </div><!-- /.sticky-header__content -->
        </div><!-- /.stricky-header -->


        <div class="stricky-header stricked-menu main-menu">
            <div class="sticky-header__content">

            </div><!-- /.sticky-header__content -->
        </div><!-- /.stricky-header -->



    <!--Page Header Start-->
    <section class="page-header clearfix" style="background-image: url(<?php echo e(asset('frontend_assets/images/backgrounds/page-header-bg.jpg')); ?>);">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="page-header__wrapper clearfix">
                        <div class="page-header__title">
                            <h2>Courses</h2>
                        </div>
                        <div class="page-header__menu">
                            <ul class="page-header__menu-list list-unstyled clearfix">
                                <li><a href="index.html">Home</a></li>
                                <li class="active">Courses</li>
                            </ul>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!--Page Header End-->



    <!--Courses One Start-->
    <section class="courses-one courses-one--courses">
        <div class="container">
            <div class="section-title text-center">
                <span class="section-title__tagline">Checkout New List</span>
                <h2 class="section-title__title">Explore Courses</h2>
            </div>

            <div class="row">
                <!--Start case-studies-one Top-->
                <div class="courses-one--courses__top">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                        <div class="courses-one--courses__menu-box">
                            <ul class="project-filter clearfix post-filter has-dynamic-filters-counter list-unstyled">
                                
                            </ul>
                        </div>
                    </div>
                </div>
                <!--End case-studies-one Top-->
            </div>


            <div class="row filter-layout masonary-layout">
                <!--Start Single Courses One-->

                <?php $__empty_1 = true; $__currentLoopData = $getAllData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $video_id = explode("?v=", $data->video_url);
                    $video_id = $video_id[1];
                ?>
                <a target="_blank" href="<?php echo e('https://www.youtube.com/' . 'embed/' . $video_id); ?>">
                        <div class="col-xl-3 col-lg-6 col-md-6 filter-item development business">
                            <div class="courses-one__single wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1000ms">
                                <div class="courses-one__single-img">

                                    <img src="<?php echo e('http://img.youtube.com/vi/' . $video_id . '/maxresdefault.jpg'); ?>" alt=""/>
                                    <div class="overlay-text">
                                        
                                    </div>
                                </div>
                                <div class="courses-one__single-content">
                                    <div class="courses-one__single-content-overlay-img">
                                        <img src="frontend_assets/images/resources/courses-v1-overlay-img1.png" alt=""/>
                                    </div>
                                    <h6 class="courses-one__single-content-name"><?php echo e($data->Subject->author); ?></h6>
                                    <h4 class="courses-one__single-content-title"><a href="course-details.html"><?php echo e($data->Subject->subject_name); ?></a></h4>

                                    <p style="font-size: 12px;"> <b>Lecture Title:</b> <span style="text-transform: capitalize;"><?php echo e($data->video_title); ?></span></p>
                                    <ul class="courses-one__single-content-courses-info list-unstyled">
                                        <li>Uploaded at:</li>
                                        
                                        <li><?php echo e(date('d-M-Y', strtotime($data->created_at))); ?></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
               </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="filter-item text-center">
                        <h4 class="mt-5 text-danger">No Relevent Data Found..!</h4>
                    </div>
                <?php endif; ?>
                <!--End Single Courses One-->

            </div>

        </div>

    </section>
    <!--Courses One End-->
















    </div><!-- /.page-wrapper -->


    <a href="courses.html#" data-target="html" class="scroll-to-target scroll-to-top"><i class="fa fa-angle-up"></i></a>


    <?php $__env->startPush('frontend_css'); ?>
    <style>
        .pagination{
            margin-top: 10px;
            display: flex;
            justify-content: center;
        }
        .page-link {
            background-color: #085da3;
            color: #fff;
            margin: 0 10px;
            width: 120px;
            text-align: center;
        }
        .page-link:hover {
            background-color: #5F61E6;
            color: #fff;
        }
        .page-item{
            margin: 0 5px;
        }
        .page-item.disabled .page-link {
            background-color: #5F61E6;
            color: #fff;
        }
        @media (max-width: 575.98px) {
            table {
                width: 100%;
                margin-top: 20px !important;
            }
        }
    </style>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\school\happy_school_backup\resources\views/frontend/cources/searchCourch.blade.php ENDPATH**/ ?>