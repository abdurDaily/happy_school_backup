<?php $__env->startSection('admin_main_content'); ?>
    <div class="container">
        <div class="row">


            <div class="col-lg-4">
                <div class="row">


                    
                    <div class="col-lg-12 card shadow">
                        <div class="card-header">
                            <h5 style="margin: 0; padding:0;">Add new course</h5>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('admin.store.course')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <label for="course_name" class="mb-0">course name</label>
                                <input value="<?php echo e(old('course_name')); ?>" id="course_name" name="course_name" type="text" class="form-control"
                                    placeholder="course name..">
                                <?php $__errorArgs = ['course_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span> <br>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                <label for="semester_id" class="mt-2">Select Class</label>
                                <select name="semester_id" id="semester_id" class="form-control">
                                    <option value="" selected disabled>Slect a Class</option>

                                    <?php $__currentLoopData = $semesterData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semester): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option  value="<?php echo e($semester->id); ?>"><?php echo e($semester->semester); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['semester_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span> <br>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                                <button class="btn btn-primary w-100 mt-3">Upload</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>


            <div class="col-lg-8 table-responsive mt-5 mt-lg-0">
                <div class="card shadow table-responsive">
                    <table class="table table-striped table-hover text-center text-capitalize ">
                        <tr>
                            <td>Sn.</td>
                            <td align="left">Subject Name</td>
                            <td align="center">Semester</td>
                            <td>Action</td>
                        </tr>


                        <?php $__empty_1 = true; $__currentLoopData = $subjectData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($subjectData->firstItem() + $key); ?></td>
                                <td align="left"><?php echo e(Str::limit($data->subject_name, 20)); ?></td>
                                <td>
                                    <span class="badge bg-primary text-white"><?php echo e($data->semester->semester); ?></span>

                                </td>
                                <td>
                                    <div class="btn-group">
                                        <a href="<?php echo e(route('admin.edit.course', $data->id)); ?>"
                                            class="btn btn-primary btn-sm"><i class="fa-solid fa-pen-to-square"></i></a>
                                        <a href="<?php echo e(route('admin.delete.course', $data->id)); ?>"
                                            class="btn btn-danger btn-sm"><i class="fa-solid fa-trash"></i></a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </table>

                    <?php echo e($subjectData->links()); ?>

                </div>
            </div>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('additional_css'); ?>
    <style>
        .pagination{
            margin-top: 10px;
            /* background-color: red; */
            display: flex;
            justify-content: center;
        }
        .page-link {
            background-color: #085da3;
            color: #fff;
            margin: 0 10px;
            width: 100px;
        }
        .page-link:hover {
            background-color: #5F61E6;
            color: #fff;
        }
        .page-item.disabled .page-link {
            background-color: #5F61E6;
            color: #fff;
        }
        @media (max-width: 575.98px) {
            table {
                width: 100%;
                margin-top: 20px !important;
            }
        }
    </style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\school\happy_school_backup\resources\views/admin/courses/addCourse.blade.php ENDPATH**/ ?>