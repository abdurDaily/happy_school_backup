
<?php $__env->startSection('frontend_layout'); ?>
    <section class="my-5">
        <div class="container">
            <div class="row gx-5">
                <?php $__empty_1 = true; $__currentLoopData = $videoData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-lg-2">
                        <div class="shadow">
                            <?php echo e(dd($data->video_link)); ?>

                            <img class="img-fluid" src="<?php echo e(); ?>" alt="">
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <h4>No Documentary Found🤔</h4>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\school\happy_school_backup\resources\views/frontend/galary/video.blade.php ENDPATH**/ ?>