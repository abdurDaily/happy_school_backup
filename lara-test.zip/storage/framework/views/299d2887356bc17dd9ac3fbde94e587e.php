<?php $__env->startSection('admin_main_content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12 mx-auto shadow card">
                <div class="card">

                    <?php $__errorArgs = ['hasAttendance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="card">
                        <div class="card-header p-0">
                            <div class="alert-danger">
                                <h5 class="text-center py-4"><?php echo e($message); ?></h5>
                             </div>
                        </div>
                     </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <div class="card-header m-0 p-0 d-flex justify-content-end">
                        <h5 class="py-2 w-25 bg-primary text-center" style="color:#fafafa; font-weight:lighter; border-radius:5px; font-size:16px;">Provide Attendance</h5>
                    </div>
                    <div class="card-body p-0">
                        <div class="row">
                            <div class="col-md-7 mx-auto p-3 mb-3">
                                <form action="<?php echo e(route('check.present')); ?>" method="GET">
                                    <?php echo csrf_field(); ?>

                                    <div class="row input-group mx-auto btn-group">
                                        <div class="btn-group shadow mx-auto p-0">
                                            <select required name="batch_id" id="batch_id" class="form-control">
                                                <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($data->id); ?>"><?php echo e($data->batch_no); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <button class="btn btn-primary">Submit</button>
                                        </div>
                                    </div>
                            </div>
                            </form>
                        </div>


                        <?php if(isset(request()->batch_id) ): ?>

                    

                        <?php if(count($studentInfo) > 0): ?>
                            <form action="<?php echo e(route('present.submit')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <label for="date">Select Date</label>
                                        <input required name="date" id="date" type="date"
                                            class="form-control">
                                        <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><strong><?php echo e($message); ?></strong></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>





                                    


                                    <div class="col-lg-6">
                                        <label for="subject_id">Select Subject</label>
                                        <select style="border: 1px solid red !importent;" required name="subject_id" id="subject_id" class="form-control">
                                            <option value="" selected disabled>Select a batch</option>
                                            <?php $__currentLoopData = $subjectId; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subjectData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($subjectData->id); ?>"><?php echo e($subjectData->subject_name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <input name="check_id" type="hidden"
                                            value="<?php echo e(isset(request()->batch_id) ? request()->batch_id : ''); ?>">
                                    </div>
                                </div>

                                <table class="table table-responsive table-striped table-hover mt-5">
                                    <tr>
                                        <th>SN</th>
                                        <th>Name</th>
                                        <th>Std id</th>
                                        <th>Status</th>
                                        
                                    </tr>
                                    <?php $__empty_1 = true; $__currentLoopData = $studentInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($detail->id); ?></td>
                                            <td><?php echo e($detail->std_name); ?></td>
                                            <td>
                                                <?php echo e($detail->std_id); ?>

                                            </td>
                                            <td>
                                                <div class="form-check form-switch">
                                                    <input name="isPresent[]" class="form-check-input"
                                                        value="<?php echo e($detail->id); ?>" type="checkbox"
                                                        id="flexSwitchCheckDefault">
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <?php endif; ?>
                                </table>

                                <button class="btn btn-primary w-100 my-3">Submit</button>
                            </form>
                        <?php else: ?>
                            <h5 class="text-center">No Student Admitted in this batch!</h5>
                        <?php endif; ?>
                            

                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>





<?php $__env->startPush('additional_css'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css"
        integrity="sha512-nMNlpuaDPrqlEls3IX/Q56H36qvBASwb3ipuo3MxeWbsQB1881ox0cRv7UPTgBlriqoynt35KjEwgGUeUXIPnw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        .select2-container {
            border: 1px solid #D3D8DE;
            border-radius: 6px;
        }
        .select2-container--default .select2-selection--single {
            border: none;
            height: 40px;
            text-align: center;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .select2-search__field {
            border: 0;
            outline: 0;
        }

        .batch_no,
        .select2-selection__rendered {
            border: 0px solid transparent;
            outline: none;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('additional_js'); ?>
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"
        integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"
        integrity="sha512-2ImtlRlf2VVmiGZsjm9bEyhjGW4dU7B6TNwh/hx/iSByxNENtj3WVE6o/9Lj4TJeVXPi4bnOIMXFIJJAeufa0A=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <script>
        $(document).ready(function() {
            $('#batch_no').select2();
            $('#subject_id').select2();
            $('#batch_id').select2();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\school\happy_school_backup\resources\views/Admin/Attendance/present.blade.php ENDPATH**/ ?>